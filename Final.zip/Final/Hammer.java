import java.awt.Color;
import java.awt.Graphics;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import java.io.IOException;

public class Hammer extends Item{

  public Hammer(int x, int y, BufferedImage hammer, int scene){
    super(x, y, hammer, scene);

  }

}
