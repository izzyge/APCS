import java.awt.Color;
import java.awt.Graphics;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import java.io.IOException;

public class Apple extends Item{

  public Apple(int x, int y, BufferedImage apple, int scene){
    super(x, y, apple, scene);

  }

}
