import java.awt.Color;
import java.awt.Graphics;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import java.io.IOException;

public class FastPotion extends Item{

  public FastPotion(int x, int y, BufferedImage fastPotion, int scene){
    super(x, y, fastPotion, scene);

  }

}
