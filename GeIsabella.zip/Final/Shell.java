import java.awt.Color;
import java.awt.Graphics;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import java.io.IOException;

public class Shell extends Item{

  public Shell(int x, int y, BufferedImage shell, int scene){
    super(x, y, shell, scene);

  }

}
