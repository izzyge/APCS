Presentation:
https://docs.google.com/presentation/d/1UatLRvI945B44dKw96RtoBAz0xQLan-x_g1V9psUH1g/edit?usp=sharing

Please follow the directional arrows!!
