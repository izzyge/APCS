import java.awt.Color;
import java.awt.Graphics;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import java.io.IOException;

public class EscPotion extends Item{

  public EscPotion(int x, int y, BufferedImage escPotion, int scene){
    super(x, y, escPotion, scene);

  }

}
